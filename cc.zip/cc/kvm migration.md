## KVM Live Migration on Two PCs (SSH + NFS), Easy Way

**Idea:** both PCs share one folder through NFS. The VM’s disk lives in that folder, so only RAM moves during migration.

I use `PC-A` (source, NFS server) and `PC-B` (destination). Replace `IP_A` and `IP_B` with the real IPs, and `user` with your username (same on both PCs if possible).

---

### Step 1: Check the network (both PCs)

bash

```bash
ip a                      # note each PC's IP
ping -c 2 IP_B            # from A
```

Keep the college proxy away from PC-to-PC traffic, and stop the firewall for the lab:

bash

```bash
unset http_proxy https_proxy
sudo systemctl stop ufw firewalld 2>/dev/null
echo "IP_A pcA" | sudo tee -a /etc/hosts
echo "IP_B pcB" | sudo tee -a /etc/hosts
```

### Step 2: Install KVM, SSH, NFS (both PCs)

bash

```bash
sudo pacman -S qemu-full libvirt virt-manager virt-install dnsmasq iptables-nft openssh nfs-utils
sudo systemctl enable --now libvirtd.socket sshd
sudo usermod -aG libvirt $USER
sudo modprobe bridge
sudo virsh net-start default
sudo virsh net-autostart default
```

Log out and in again. (Ubuntu PCs: `qemu-kvm libvirt-daemon-system virtinst virt-manager nfs-common openssh-server`.)

### Step 3: SSH without a password (A to B)

On PC-A:

bash

```bash
ssh-keygen                       # press Enter for everything
ssh-copy-id user@pcB
ssh user@pcB hostname            # no password asked
virsh -c qemu+ssh://user@pcB/system list --all    # empty list, no error
```

### Step 4: NFS shared folder

**PC-A:**

bash

```bash
sudo mkdir -p /srv/vmstore
sudo chmod 777 /srv/vmstore
echo "/srv/vmstore IP_B(rw,sync,no_root_squash)" | sudo tee -a /etc/exports
sudo systemctl enable --now nfs-server
sudo exportfs -ra
```

**PC-B:**

bash

```bash
sudo mkdir -p /srv/vmstore
sudo mount -t nfs IP_A:/srv/vmstore /srv/vmstore
df -h | grep vmstore
```

Test: `touch /srv/vmstore/test` on A, then `ls /srv/vmstore` on B. The path must be **identical** on both.

### Step 5: Create the VM on PC-A (disk in the shared folder)

bash

```bash
sudo virt-install --name vm1 --ram 1024 --vcpus 1 \
  --disk path=/srv/vmstore/vm1.qcow2,size=8,format=qcow2 \
  --cdrom /var/lib/libvirt/images/ubuntu-22.04-live-server-amd64.iso \
  --os-variant ubuntu22.04 --network network=default --graphics vnc
```

Install Ubuntu in virt-manager, then **remove the CDROM device** (Details > SATA CDROM > Remove). Check:

bash

```bash
sudo virsh domblklist vm1        # must show /srv/vmstore/vm1.qcow2
```

On PC-B make sure `default` is active: `sudo virsh net-list --all`.

Inside the VM run a visible counter:

bash

```bash
while true; do date; sleep 1; done
```

### Step 6: Live migrate (on PC-A)

bash

```bash
virsh migrate --live --verbose --persistent --undefinesource vm1 qemu+ssh://user@pcB/system
```

If you get a permission error on the NFS disk, add `--unsafe`, or check `no_root_squash` and `chmod 777`.

### Step 7: Verify

bash

```bash
virsh list --all          # PC-A: vm1 gone
virsh list --all          # PC-B: vm1 running
```

Open `virt-viewer vm1` on PC-B. The counter is still running. To go back, run the same command on PC-B with `pcA`.

---

### Quick fixes

|Problem|Fix|
|---|---|
|Can’t ping PC-B|Network blocks PC-to-PC, so use a LAN cable between them|
|`Cannot access storage file`|NFS not mounted on B, or the path differs|
|Stuck at 0%|Firewall blocks ports 49152-49215, so stop it|
|`Network 'default' not active`|`sudo virsh net-start default` on B|
|CPU mismatch|Add `--unsafe`|

**Note:** each PC has its own NAT network, so prove the VM kept running with the console counter, not by pinging from PC-A.

### Flow to remember

1. Ping works, firewall off
2. Install KVM, start libvirt and `default`
3. SSH key A to B
4. NFS export on A, mount on B (same path)
5. VM on A with its disk in `/srv/vmstore`
6. `virsh migrate --live --verbose vm1 qemu+ssh://user@pcB/system`
7. `virsh list` on both