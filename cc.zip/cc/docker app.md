## Experiment 3: Final Steps (Two-Container Docker App, with College Proxy)

Everything is done in the exam: no home preparation. Your proxy is `19.21.112.12` with a port. I use `PORT` below, so replace it with the real port (for example `3128` or `8080`). The proxy address then looks like `http://19.21.112.12:PORT`.

```
Browser → Frontend :8080 (form) → Backend :5000 (saves data.txt)
```

---

### Part A: Install and start Docker (Arch)

bash

```bash
sudo pacman -S docker
sudo systemctl enable --now docker
sudo systemctl status docker        # active (running), press q to exit
```

If it won’t start after a system update, run `reboot` and then `sudo systemctl start docker`.

---

### Part B: Set the college proxy (do this before any pull or build)

Docker needs the proxy in **two places**: the Docker service (to pull images) and the build (for `pip install`).

**B1. Proxy for the Docker service (pulls `python` and `nginx` images)**

bash

```bash
sudo mkdir -p /etc/systemd/system/docker.service.d
sudo nano /etc/systemd/system/docker.service.d/proxy.conf
```

Paste this (change `PORT`):

```
[Service]
Environment="HTTP_PROXY=http://19.21.112.12:PORT"
Environment="HTTPS_PROXY=http://19.21.112.12:PORT"
Environment="NO_PROXY=localhost,127.0.0.1"
```

Save with `Ctrl+O`, `Enter`, `Ctrl+X`. Then:

bash

```bash
sudo systemctl daemon-reload
sudo systemctl restart docker
sudo systemctl show docker --property=Environment     # should show your proxy
```

**B2. Test that Docker can pull**

bash

```bash
sudo docker pull python:3.11-slim
sudo docker pull nginx:alpine
```

Both must finish with `Downloaded` or `up to date`.

**B3. If the proxy needs a username and password**, write it like this in the file above:

```
http://USERNAME:PASSWORD@19.21.112.12:PORT
```

(The proxy is used for the build in Part E through `--build-arg`, so `pip install` works too.)

---

### Part C: Create the files

bash

```bash
mkdir -p ~/exp3/frontend ~/exp3/backend
cd ~/exp3
```

**backend/app.py** (`nano ~/exp3/backend/app.py`)

python

```python
from flask import Flask, request

app = Flask(__name__)

@app.route("/save")
def save():
    name = request.args.get("name")
    email = request.args.get("email")
    phone = request.args.get("phone")
    open("data.txt", "a").write(name + " | " + email + " | " + phone + "\n")
    return "Saved! <a href='http://localhost:8080'>Back</a>"

@app.route("/show")
def show():
    return open("data.txt").read().replace("\n", "<br>")

app.run(host="0.0.0.0", port=5000)
```

Check the colons in `def save():` and `def show():`.

**backend/Dockerfile**

```
FROM python:3.11-slim
WORKDIR /app
RUN pip install flask
COPY app.py .
RUN touch data.txt
CMD ["python", "app.py"]
```

**frontend/index.html**

html

```html
<h2>Student Form</h2>
<form action="http://localhost:5000/save">
  Name: <input name="name"><br><br>
  Email: <input name="email"><br><br>
  Phone: <input name="phone"><br><br>
  <button>Submit</button>
</form>
<br>
<a href="http://localhost:5000/show">View Saved Data</a>
```

**frontend/Dockerfile**

```
FROM nginx:alpine
COPY index.html /usr/share/nginx/html/
```

---

### Part D: Build and run (with the proxy)

bash

```bash
cd ~/exp3
sudo docker rm -f backend frontend 2>/dev/null

sudo docker build \
  --build-arg HTTP_PROXY=http://19.21.112.12:PORT \
  --build-arg HTTPS_PROXY=http://19.21.112.12:PORT \
  -t backend ./backend

sudo docker build -t frontend ./frontend

sudo docker run -d --name backend -p 5000:5000 backend
sudo docker run -d --name frontend -p 8080:80 frontend
sleep 3
sudo docker ps
```

Both containers must show `Up`. Only the backend build needs the proxy arguments, because only it runs `pip install`.

---

### Part E: Test

1. Open `http://localhost:8080`.
2. Fill in Name, Email, Phone and click **Submit**. You see “Saved!”.
3. Click **View Saved Data** (or open `http://localhost:5000/show`).
4. Verify inside the container:

bash

```bash
sudo docker exec backend cat data.txt
```

**Screenshots for the report:** `docker ps`, the form page, the saved data page, the `docker exec` output.

---

### If the build still fails

|Error|Fix|
|---|---|
|`pip` times out or “Could not find a version”|Check that the proxy and port are correct in the `--build-arg` lines. Or use the no-pip fallback below|
|`pull` timeout or “connection refused”|Wrong proxy port, or the `proxy.conf` was not loaded: run `daemon-reload` and `restart docker` again|
|“proxyconnect ... 407”|The proxy needs a username and password (see B3)|
|Container exits right away|`sudo docker logs backend` shows the error, usually a typo in `app.py`. Fix it and rebuild|

**No-pip fallback (if pip is blocked even with the proxy):** replace **backend/app.py** with the standard-library version below, and remove the `RUN pip install flask` line from the backend Dockerfile. Then no proxy is needed for the backend build.

python

```python
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs

class H(BaseHTTPRequestHandler):
    def do_GET(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)
        if u.path == "/save":
            line = " | ".join(q.get(k, [""])[0] for k in ("name", "email", "phone"))
            open("data.txt", "a").write(line + "\n")
            out = "Saved! <a href='http://localhost:8080'>Back</a>"
        else:
            out = open("data.txt").read().replace("\n", "<br>")
        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.end_headers()
        self.wfile.write(out.encode())

HTTPServer(("0.0.0.0", 5000), H).serve_forever()
```

---

### Cleanup (optional, after the exam)

bash

```bash
sudo docker rm -f frontend backend
sudo docker rmi frontend backend
sudo rm /etc/systemd/system/docker.service.d/proxy.conf
sudo systemctl daemon-reload && sudo systemctl restart docker
```

---

### Exam rules

1. **Set the proxy first (Part B)**, then pull and build.
2. Container exits right after starting: `sudo docker logs <name>`.
3. Changed any code: rebuild the image, remove the old container, run it again.
4. Frontend is on port 8080 and backend on port 5000. The form field names must match the backend’s `request.args.get("...")` names.

Tell me the real proxy port if you want me to write the final commands with the exact number.