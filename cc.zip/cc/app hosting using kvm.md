## Experiment 8: Hosting an App using KVM (Easy Version)

**Aim:** run a web page inside a KVM VM and open it from the host.

```
Host (browser/curl) → virbr0 → appvm (192.168.122.20, nginx)
```

### Step 1: Host setup (Arch, once)

bash

```bash
sudo pacman -S qemu-full libvirt virt-manager virt-install dnsmasq iptables-nft
sudo systemctl enable --now libvirtd.socket
sudo usermod -aG libvirt $USER
sudo modprobe bridge
sudo virsh net-start default
sudo virsh net-autostart default
sudo virsh net-list --all          # default = active
```

Log out and in again. Put the Ubuntu Server ISO in `/var/lib/libvirt/images/`.

### Step 2: Create the VM

1. Open `virt-manager` > **New VM** > Local install media (ISO).
2. Select the Ubuntu ISO, RAM 2048 MB, 2 CPUs, 10 GB disk.
3. Name: `appvm`. Network: **Virtual network ‘default’ : NAT**.
4. Install Ubuntu and tick **Install OpenSSH server**.

### Step 3: Set a fixed IP (inside the VM)

bash

```bash
ip a                                   # note the interface name, e.g. enp1s0
sudo nano /etc/netplan/50-cloud-init.yaml
```

yaml

```yaml
network:
  version: 2
  ethernets:
    enp1s0:
      addresses: [192.168.122.20/24]
      routes:
        - to: default
          via: 192.168.122.1
      nameservers:
        addresses: [8.8.8.8]
```

Use your real interface name, spaces only.

bash

```bash
sudo netplan apply
```

On the host check: `ping -c 2 192.168.122.20`.

If the ping fails, run `sudo virsh destroy appvm` then `sudo virsh start appvm`.

### Step 4: Set the college proxy (inside the VM)

Replace `PORT` with the real port:

bash

```bash
echo 'Acquire::http::Proxy "http://19.21.112.12:PORT";' | sudo tee /etc/apt/apt.conf.d/95proxy
```

### Step 5: Install nginx and create the page (inside the VM)

bash

```bash
sudo apt update
sudo apt install -y nginx
echo "<h1>My App hosted on a KVM VM</h1>" | sudo tee /var/www/html/index.html
sudo systemctl enable --now nginx
```

### Step 6: Test from the host

bash

```bash
curl http://192.168.122.20
```

Output: `<h1>My App hosted on a KVM VM</h1>`. Also open `http://192.168.122.20` in the browser.

### Screenshots for the report

1. `virsh list` showing `appvm` running
2. `virsh net-list` showing `default` active
3. `ip a` in the VM showing 192.168.122.20
4. Browser or curl output from the host

### Quick fixes

|Problem|Fix|
|---|---|
|Can’t ping VM|`ip link show master virbr0` must list a `vnet`; if not, destroy and start the VM|
|`apt update` fails|Check the proxy and port, or `ping 8.8.8.8`|
|curl refused|`sudo systemctl status nginx`|

### Viva line

“I created a VM on KVM’s NAT network (virbr0), installed nginx inside it, and accessed the page from the host at the VM’s IP.”

### Flow to remember

1. `default` network active
2. Create VM (NAT)
3. Static IP 192.168.122.20
4. Install nginx, write the page
5. `curl` from the host