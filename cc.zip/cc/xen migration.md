## Xen Live Migration on Two College PCs (Detailed)

**Aim:** move a running Xen guest (DomU) from PC-A to PC-B over the network while it keeps running, using shared storage.

I’m using Debian/Ubuntu commands, because Xen is not practical on Arch (it is AUR-only and needs a manual Xen boot setup). Debian has the best Xen support. Recent Ubuntu releases dropped or limited Xen packages, so ask your lab which OS the PCs use.

**Correction to my last message:** `xl migrate` sends everything through the SSH connection. Port 8002 was only for the old `xend` tool, and you don’t need it.

---

### 1. How it works

```
        College LAN
 ┌───────────────┐        ┌───────────────┐
 │ PC-A (Dom0)   │  SSH   │ PC-B (Dom0)   │
 │ guest vm1 ▶───┼───────▶│ vm1 resumes   │
 │ NFS server    │        │ NFS client    │
 │ /xen-vms ─────┼────────┼─ /xen-vms     │  same disk, same path
 └───────────────┘        └───────────────┘
```

1. The guest’s disk is on NFS, so both PCs can read it. Only RAM and CPU state move.
2. `xl migrate` copies the guest’s memory pages to PC-B while the guest keeps running.
3. Pages that changed during the copy are re-sent, round after round.
4. The guest is paused for a fraction of a second, the last pages are sent, and it resumes on PC-B.
5. The guest is removed from PC-A.

**Terms:**

- **Dom0:** the privileged control domain, the host OS you log into
- **DomU:** a guest VM
- **xl:** the Xen management tool (`xl list`, `xl create`, `xl migrate`)

---

### 2. What you need

|Item|Requirement|
|---|---|
|PCs|Two, on the same LAN, able to ping each other|
|Xen|Installed on both, **same version**, both booted into the Xen kernel|
|CPU|Same vendor (Intel with Intel, or AMD with AMD), similar models|
|Shared storage|NFS folder mounted at the **same path** on both|
|SSH|Passwordless **root** SSH from A to B|
|Bridge|The same bridge name (`xenbr0`) on both PCs|
|Guest|A small guest image (a ready one from the lab is easiest)|

Names used below: `PC-A` (source, NFS server), `PC-B` (destination), with `IP_A` and `IP_B` as their real IPs.

---

### 3. Step by step

#### Step 1: Check Xen is running (both PCs)

bash

```bash
sudo xl info | head
sudo xl list
```

Expected:

```
Name          ID   Mem VCPUs  State   Time(s)
Domain-0       0  ...     ...  r-----   ...
```

If `xl list` fails, you booted the normal kernel. Reboot and choose the **Xen** entry in the GRUB menu (under “Advanced options”).

Check that the versions match:

bash

```bash
xl info | grep xen_version
```

Run this on both PCs; the numbers should be the same.

#### Step 2: Install Xen (only if it’s missing, Debian)

bash

```bash
sudo apt update
sudo apt install -y xen-system-amd64 xen-tools nfs-common openssh-server bridge-utils
sudo reboot
```

Pick the Xen entry in GRUB, then run `sudo xl list` again. If apt fails because of the college proxy, set it first:

bash

```bash
echo 'Acquire::http::Proxy "http://19.21.112.12:PORT";' | sudo tee /etc/apt/apt.conf.d/95proxy
```

(Replace `PORT` with your real proxy port.)

#### Step 3: Network check (both PCs)

bash

```bash
ip a
ping -c 2 IP_B               # from PC-A
ping -c 2 IP_A               # from PC-B
```

Stop firewalls for the lab, and keep the proxy away from PC-to-PC traffic:

bash

```bash
sudo systemctl stop ufw firewalld 2>/dev/null
export no_proxy=localhost,127.0.0.1,IP_A,IP_B
unset http_proxy https_proxy
```

Add names on both PCs:

bash

```bash
echo "IP_A pcA" | sudo tee -a /etc/hosts
echo "IP_B pcB" | sudo tee -a /etc/hosts
```

If the college network blocks PC-to-PC traffic and ping fails, connect the two PCs with a LAN cable and give them static IPs such as `192.168.10.1` and `192.168.10.2`.

#### Step 4: Passwordless root SSH (A to B)

`xl migrate` runs as root, so the key must be root’s.

On **PC-B**, allow root login over SSH:

bash

```bash
sudo nano /etc/ssh/sshd_config
```

Set:

```
PermitRootLogin yes
```

bash

```bash
sudo systemctl restart ssh
sudo passwd root          # set a root password if none exists
```

On **PC-A**:

bash

```bash
sudo -i
ssh-keygen                # press Enter for every question
ssh-copy-id root@pcB
ssh root@pcB hostname     # must print pcB's name with NO password prompt
exit
```

#### Step 5: Network bridge for the guests (both PCs)

The guest needs a bridge named `xenbr0`, so the same config works on both hosts.

bash

```bash
ip a | grep xenbr0
```

If it exists, continue. If not, create it on **both** PCs (replace `eno1` with your wired interface from `ip a`):

bash

```bash
sudo nano /etc/network/interfaces
```

```
auto xenbr0
iface xenbr0 inet dhcp
    bridge_ports eno1
```

bash

```bash
sudo systemctl restart networking
```

Do this while sitting at the PC, not over SSH, because the network can drop briefly. If your lab PCs already have a bridge with another name (for example `br0`), use that name in the guest config on both PCs.

#### Step 6: Shared storage with NFS

**PC-A (server):**

bash

```bash
sudo apt install -y nfs-kernel-server
sudo mkdir -p /xen-vms
echo "/xen-vms IP_B(rw,sync,no_root_squash)" | sudo tee -a /etc/exports
sudo exportfs -ra
sudo systemctl restart nfs-kernel-server
sudo exportfs -v
```

**PC-B (client):**

bash

```bash
sudo mkdir -p /xen-vms
sudo mount -t nfs IP_A:/xen-vms /xen-vms
df -h | grep xen-vms
```

Test:

bash

```bash
touch /xen-vms/test        # on PC-A
ls /xen-vms                # on PC-B, should show "test"
```

The path must be exactly `/xen-vms` on both.

#### Step 7: Create the guest on PC-A

**Option A (easiest): use a ready image from the lab.** Copy it to `/xen-vms/vm1.img` and skip to the config file.

**Option B: install a small OS from an ISO.** A tiny ISO (Alpine or TinyCore) installs much faster than Ubuntu Server, which matters in an exam.

bash

```bash
sudo truncate -s 5G /xen-vms/vm1.img
sudo cp /path/to/small.iso /xen-vms/small.iso
```

**/xen-vms/vm1.cfg**

```
name      = "vm1"
type      = "hvm"
memory    = 512
vcpus     = 1
disk      = ['file:/xen-vms/vm1.img,xvda,w', 'file:/xen-vms/small.iso,hdc:cdrom,r']
vif       = ['bridge=xenbr0']
boot      = "dc"
vnc       = 1
vnclisten = "0.0.0.0"
```

Start it:

bash

```bash
sudo xl create /xen-vms/vm1.cfg
sudo xl list
```

Install the OS by connecting a VNC viewer to `IP_A:0` (for example `vncviewer IP_A:0`).

**After installing, edit the config:**

- Remove the cdrom entry from `disk`, so it reads `disk = ['file:/xen-vms/vm1.img,xvda,w']`
- Change `boot = "c"`

Then restart the guest:

bash

```bash
sudo xl destroy vm1
sudo xl create /xen-vms/vm1.cfg
```

Migration can fail on a cdrom whose ISO path is not available on the other PC, so detach it before migrating.

#### Step 8: Start something visible in the guest

Open the guest through VNC (or `sudo xl console vm1`; exit the console with `Ctrl+]`). Run:

bash

```bash
while true; do date; sleep 1; done
```

If the guest has an IP on the college LAN, you can also ping it from a third machine (`ping <guest-ip>`) during the migration.

#### Step 9: Migrate (on PC-A)

bash

```bash
sudo xl list                  # vm1 is listed here
sudo xl migrate vm1 pcB
```

Expected messages:

```
migration target: Ready to receive domain.
Saving to migration stream new xl format (info 0x3/0x0/...)
Loading new save file <incoming migration stream> (new xl fmt info ...)
 Savefile contains xl domain config in JSON format
Parsing config from <saved>
migration target: Transfer complete, requesting permission to start domain.
migration sender: Target has acknowledged transfer.
migration sender: Giving target permission to start.
migration target: Domain started successfully.
migration sender: Target reports successful startup.
Migration successful.
```

#### Step 10: Verify

bash

```bash
sudo xl list          # PC-A: vm1 is gone
sudo xl list          # PC-B: vm1 is listed and running
```

Open the guest console on PC-B (`sudo xl console vm1` or VNC to `IP_B:0`). The date counter kept running, and its timestamps show only a tiny gap at the switch.

To migrate back, run on PC-B: `sudo xl migrate vm1 pcA`.

---

### 4. Useful options

|Command|Meaning|
|---|---|
|`xl migrate vm1 pcB`|Live migration (default)|
|`xl migrate -e vm1 pcB`|Don’t wait for the console to close|
|`xl migrate --debug vm1 pcB`|Verify the memory transfer (slower)|
|`xl save vm1 /xen-vms/vm1.save` then `xl restore`|Non-live alternative: suspend to a file, then restore on the other host|
|`xl list`|Show running domains|
|`xl console vm1`|Guest console (exit with `Ctrl+]`)|
|`xl destroy vm1`|Force off|
|`xl shutdown vm1`|Graceful shutdown|

---

### 5. Troubleshooting

|Problem|Cause and fix|
|---|---|
|`xl list` fails|You didn’t boot the Xen kernel. Choose Xen in GRUB|
|Migration says the disk is not found|`/xen-vms` is not mounted on PC-B, or the path differs. Check `df -h`|
|SSH asks for a password|Redo `ssh-copy-id root@pcB` as root, and check `PermitRootLogin yes`|
|`Network not found` or `xenbr0` error|The bridge is missing or has another name on PC-B. Use the same name on both|
|Stuck at “Ready to receive domain”|Firewall, or a Xen version mismatch. Stop the firewall and compare `xl info`|
|`domain is not running` or a cdrom error|Detach the ISO and use `boot = "c"`|
|NFS mount fails|`nfs-kernel-server` is not running on A, or the export is for the wrong IP|
|Guest has no network after the move|The bridge on PC-B has no uplink, or the college LAN blocks the guest’s MAC|
|Migrating hangs on a busy guest|Memory changes faster than it copies. Reduce the load in the guest|

---

### 6. Report content

- **Aim:** live migration of a Xen guest between two hosts
- **Network diagram:** the picture in section 1
- **Commands:** SSH keys, NFS, the guest config, `xl migrate`
- **Screenshots:** (1) `xl list` on both PCs before, (2) `df -h` showing the NFS mount, (3) the `xl migrate` output ending in “Migration successful”, (4) `xl list` on both after, (5) the counter running in the guest
- **Conclusion:** live migration moves a running VM between hosts with almost no downtime, which allows load balancing and hardware maintenance without stopping services.

### 7. Viva answers

- **What is live migration?** Moving a running VM to another host with minimal downtime.
- **Why shared storage?** Only memory and CPU state are copied, so both hosts must see the same disk.
- **Which tool?** `xl migrate <domain> <host>`, which uses SSH.
- **Pre-copy method?** Memory is copied while the guest runs, changed pages are re-sent, then a very short pause switches it over.
- **Dom0 vs DomU?** Dom0 is the control domain, DomU are the guests.
- **Why must the Xen versions and CPUs match?** The saved guest state must be understood by the destination hypervisor and CPU.
- **Type-1 or type-2?** Xen is type-1 (bare metal).

### 8. Exam flow (memorize)

1. `xl list` on both (Domain-0 visible), and `ping` works
2. Root SSH key A to B
3. Same bridge `xenbr0` on both
4. NFS: export `/xen-vms` on A, mount on B
5. Create `vm1.cfg` and `xl create` on A, then install or use the ready image
6. Remove the cdrom, start the counter
7. `sudo xl migrate vm1 pcB`
8. `xl list` on both PCs