## Final Clean Steps: HAProxy Load Balancing on KVM (NAT only)

Only the steps that actually worked for you, in order.

**Final layout:**

|VM|IP|Role|
|---|---|---|
|lb|192.168.122.10|HAProxy|
|web1|192.168.122.11|Apache, “Server 1”|
|web2|192.168.122.12|Apache, “Server 2”|

---

### Part A: Host setup (Arch, once)

bash

```bash
sudo pacman -S qemu-full libvirt virt-manager virt-install dnsmasq iptables-nft edk2-ovmf swtpm
sudo systemctl enable --now libvirtd.socket
sudo usermod -aG libvirt $USER
sudo modprobe bridge
sudo virsh net-start default
sudo virsh net-autostart default
sudo virsh net-list --all          # default = active
```

Log out and in again after the `usermod` command. Put the Ubuntu ISO in `/var/lib/libvirt/images/`.

---

### Part B: Create the first VM (web1)

1. Open `virt-manager` > **New VM** > Local install media > Ubuntu Server ISO.
2. Network: **Virtual network ‘default’: NAT**.
3. Install Ubuntu and tick **OpenSSH server**.
4. Log in and set the static IP. Get the interface name from `ip a`, then:

bash

```bash
sudo nano /etc/netplan/50-cloud-init.yaml
```

yaml

```yaml
network:
  version: 2
  ethernets:
    <iface>:
      addresses: [192.168.122.11/24]
      routes:
        - to: default
          via: 192.168.122.1
      nameservers:
        addresses: [8.8.8.8]
```

bash

```bash
sudo netplan apply
```

5. Check from the host: `ping -c 2 192.168.122.11`
6. Install the packages (needs internet):

bash

```bash
sudo apt update
sudo apt install -y apache2 haproxy
```

7. Shut down: `sudo poweroff`

---

### Part C: Clone web1 into web2 and lb

On the host:

bash

```bash
sudo virt-clone --original web1 --name web2 --auto-clone
sudo virt-clone --original web1 --name lb --auto-clone
```

Start **only web2 first** (web1 stays off, so the IPs don’t clash):

bash

```bash
sudo virsh start web2
```

In the web2 console:

bash

```bash
ip a                                   # note the real interface name
sudo nano /etc/netplan/50-cloud-init.yaml   # set IP 192.168.122.12 and the real <iface>
sudo netplan apply
sudo rm /etc/machine-id && sudo systemd-machine-id-setup
```

Then do the same for **lb**: start it, set the IP to `192.168.122.10`, and apply. Finally start web1.

Check from the host:

bash

```bash
ip link show master virbr0             # one vnet per running VM
ping -c 2 192.168.122.10
ping -c 2 192.168.122.11
ping -c 2 192.168.122.12
```

---

### Part D: Web servers

**web1:**

bash

```bash
echo "Server 1" | sudo tee /var/www/html/index.html
sudo systemctl enable --now apache2
```

**web2:**

bash

```bash
echo "Server 2" | sudo tee /var/www/html/index.html
sudo systemctl enable --now apache2
```

Test from the host:

bash

```bash
curl http://192.168.122.11
curl http://192.168.122.12
```

---

### Part E: HAProxy on lb

bash

```bash
sudo systemctl disable --now apache2
sudo nano /etc/haproxy/haproxy.cfg
```

Append at the bottom:

```
frontend web
    bind *:80
    default_backend servers

backend servers
    balance roundrobin
    server web1 192.168.122.11:80 check
    server web2 192.168.122.12:80 check
```

bash

```bash
sudo haproxy -c -f /etc/haproxy/haproxy.cfg
sudo systemctl restart haproxy
```

---

### Part F: Final test (host)

bash

```bash
for i in {1..6}; do curl http://192.168.122.10; done
```

Output:

```
Server 1
Server 2
Server 1
Server 2
Server 1
Server 2
```

**Failover:**

bash

```bash
sudo virsh shutdown web1
for i in {1..4}; do curl http://192.168.122.10; done    # only Server 2
sudo virsh start web1
```

---

### Exam rules (from the problems you hit)

1. Start the `default` network **before** the VMs. Never restart it while the VMs run. If you do, `sudo virsh destroy <vm>` and `sudo virsh start <vm>` for each VM.
2. Take the interface name from `ip a`, never from an old file.
3. Check `ip link show master virbr0` shows one `vnet` per running VM.
4. Use static IPs. No DHCP needed.
5. Install apache2 and haproxy **before cloning**, so the clones need no internet.
6. Stop Apache on lb, because HAProxy needs port 80.