## Experiment 1: Cluster OpenMP on Two PCs (Local Network)

**Aim:** run a parallel program across two PCs so that each PC runs several OpenMP threads, and show the output from both machines.

**How it is done:** Intel’s original “Cluster OpenMP” product is discontinued, so labs do it as a hybrid of two tools:

- **MPI (OpenMPI)** starts one process on each PC and connects the PCs over the network.
- **OpenMP** creates threads inside each process, using all CPU cores of that PC.

```
PC-A (master, IP_A)  ←── LAN / SSH ──→  PC-B (worker, IP_B)
 MPI rank 0 + threads                    MPI rank 1 + threads
```

I use `PC-A` and `PC-B`, with `IP_A` and `IP_B` for their real IPs. Use the **same username on both PCs** and the **same folder path** for the program.

---

### Step 1: Check the network (both PCs)

bash

```bash
ip a                        # note each PC's IP
ping -c 2 IP_B              # from A
ping -c 2 IP_A              # from B
```

Keep the college proxy away from PC-to-PC traffic, and stop the firewall for the lab:

bash

```bash
unset http_proxy https_proxy
export no_proxy=localhost,127.0.0.1,IP_A,IP_B
sudo systemctl stop ufw firewalld 2>/dev/null
```

MPI opens random TCP ports between the PCs, so a firewall will make it hang.

Add names on **both** PCs:

bash

```bash
echo "IP_A pcA" | sudo tee -a /etc/hosts
echo "IP_B pcB" | sudo tee -a /etc/hosts
```

### Step 2: Install the tools (both PCs)

**Arch:**

bash

```bash
sudo pacman -S gcc openmpi openssh
sudo systemctl enable --now sshd
```

**Ubuntu/Debian:**

bash

```bash
sudo apt install -y build-essential openmpi-bin libopenmpi-dev openssh-server
```

Check:

bash

```bash
mpicc --version
mpirun --version
```

`gcc` already includes OpenMP support (the `-fopenmp` flag). Both PCs must have the **same OpenMPI version**.

### Step 3: Passwordless SSH (A to B)

MPI starts the remote process through SSH, so no password prompt may appear.

On PC-A:

bash

```bash
ssh-keygen                        # press Enter for every question
ssh-copy-id user@pcB              # replace "user" with your username
ssh user@pcB hostname             # must print pcB's name with NO password prompt
```

Also do the reverse (B to A), because some MPI setups need it:

bash

```bash
# on PC-B
ssh-keygen
ssh-copy-id user@pcA
```

### Step 4: Write the program (on PC-A)

bash

```bash
mkdir -p ~/cluster && cd ~/cluster
nano hybrid.c
```

c

```c
#include <mpi.h>
#include <omp.h>
#include <stdio.h>

int main(int argc, char **argv) {
    int rank, size, len;
    char host[MPI_MAX_PROCESSOR_NAME];

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    MPI_Get_processor_name(host, &len);

    #pragma omp parallel
    {
        printf("Host %s | MPI rank %d of %d | thread %d of %d\n",
               host, rank, size, omp_get_thread_num(), omp_get_num_threads());
    }

    MPI_Finalize();
    return 0;
}
```

Compile:

bash

```bash
mpicc -fopenmp hybrid.c -o hybrid
```

### Step 5: Copy the program to PC-B (same path)

MPI runs `~/cluster/hybrid` on PC-B, so the file must exist there at the same path.

bash

```bash
ssh user@pcB "mkdir -p ~/cluster"
scp ~/cluster/hybrid user@pcB:~/cluster/
```

(Or use NFS as in the migration experiment. Copying is simpler.)

### Step 6: Create the hostfile

Find the number of CPU cores on each PC with `nproc`. Then in `~/cluster/hosts`:

```
pcA slots=1
pcB slots=1
```

`slots=1` means one MPI process per PC. The threads come from OpenMP.

### Step 7: Run on both PCs

bash

```bash
cd ~/cluster
export OMP_NUM_THREADS=4          # threads per PC
mpirun --hostfile hosts -np 2 -x OMP_NUM_THREADS ./hybrid
```

`-np 2` means two MPI processes, and `-x` passes the variable to the remote PC.

**Expected output:**

```
Host pcA | MPI rank 0 of 2 | thread 0 of 4
Host pcA | MPI rank 0 of 2 | thread 2 of 4
Host pcB | MPI rank 1 of 2 | thread 0 of 4
Host pcB | MPI rank 1 of 2 | thread 1 of 4
...
```

Lines from both `pcA` and `pcB` prove that the work ran on two machines, each with its own threads.

---

### Step 8: A real computation (calculate pi)

This shows the actual use of the cluster. Each PC computes a part of the sum, and MPI combines the results.

**pi.c**

c

```c
#include <mpi.h>
#include <omp.h>
#include <stdio.h>

int main(int argc, char **argv) {
    int rank, size;
    long n = 400000000;
    double h, sum = 0.0, total = 0.0;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    double t = MPI_Wtime();
    h = 1.0 / n;

    #pragma omp parallel for reduction(+:sum)
    for (long i = rank; i < n; i += size) {
        double x = h * (i + 0.5);
        sum += 4.0 / (1.0 + x * x);
    }
    sum *= h;

    MPI_Reduce(&sum, &total, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

    if (rank == 0)
        printf("Pi = %.10f, time = %.2f s\n", total, MPI_Wtime() - t);

    MPI_Finalize();
    return 0;
}
```

bash

```bash
mpicc -fopenmp pi.c -o pi
scp pi user@pcB:~/cluster/
export OMP_NUM_THREADS=4
mpirun --hostfile hosts -np 2 -x OMP_NUM_THREADS ./pi      # both PCs
mpirun -np 1 ./pi                                          # only PC-A
```

Compare the two times. Two PCs finish in roughly half the time of one, which shows the speedup. For the numbers use a `n` large enough that the run takes a few seconds.

---

### Step 9 (optional): Pure OpenMP on a single PC

To explain the OpenMP part alone:

c

```c
#include <omp.h>
#include <stdio.h>
int main() {
    #pragma omp parallel
    printf("Hello from thread %d of %d\n", omp_get_thread_num(), omp_get_num_threads());
}
```

bash

```bash
gcc -fopenmp omp.c -o omp && OMP_NUM_THREADS=4 ./omp
```

---

### Troubleshooting

|Problem|Fix|
|---|---|
|`mpirun` hangs with no output|Firewall is on, or the PCs can’t reach each other. Stop the firewall and test ping|
|It asks for a password|SSH key not set up. Redo `ssh-copy-id`|
|`orted: command not found`|OpenMPI is not in the PATH on PC-B for non-interactive SSH. Use `mpirun --prefix /usr ...` (Arch and Ubuntu usually use `/usr`)|
|`No such file ./hybrid` on PC-B|The program wasn’t copied to the same path on PC-B|
|Hangs because of wrong network interface (Docker or virbr0 present)|Force the real interface: `mpirun --mca btl_tcp_if_include eth0 --mca oob_tcp_if_include eth0 ...` (use your real name from `ip a`, for example `enp3s0` or `wlan0`)|
|Version mismatch error|Both PCs must have the same OpenMPI version (`mpirun --version`)|
|Only one host appears in the output|The hostfile is wrong, or you used `-np 1`|
|“There are not enough slots”|Increase `slots=` in the hostfile, or add `--oversubscribe`|
|Running as root error|Run as a normal user, or add `--allow-run-as-root`|

---

### Report content

- **Aim:** run an OpenMP and MPI hybrid program on a two-PC cluster
- **Diagram:** the picture at the top
- **Commands:** SSH keys, the hostfile, the compile and run lines
- **Screenshots:** (1) `ssh user@pcB hostname` without a password, (2) the hybrid output showing both hosts, (3) the pi result with the time on one PC and on two PCs
- **Conclusion:** OpenMP uses the cores inside one PC (shared memory), and MPI links several PCs (distributed memory). Together they let a program use the full CPU power of a cluster.

### Viva answers

- **What is OpenMP?** An API that uses compiler directives (`#pragma omp`) to run code with multiple threads on shared memory.
- **What is MPI?** A message-passing library for processes running on different machines.
- **Why both?** OpenMP works only inside one machine. MPI is needed to connect machines.
- **What does `-fopenmp` do?** It enables OpenMP support in gcc.
- **What is a hostfile?** A file that lists the machines and the number of processes (slots) for each.
- **Why SSH?** `mpirun` uses SSH to start the process on the remote PC.
- **What is `reduction(+:sum)`?** Each thread keeps its own partial sum, and OpenMP adds them safely at the end.
- **Shared vs distributed memory:** threads share memory in one PC, while MPI processes on different PCs have separate memory and exchange data by messages.

### Flow to remember

1. Ping works, firewall off, proxy unset
2. Install `gcc openmpi openssh` on both
3. SSH key A to B
4. Write `hybrid.c`, run `mpicc -fopenmp hybrid.c -o hybrid`
5. `scp` the program to PC-B at the same path
6. Hostfile: `pcA slots=1` and `pcB slots=1`
7. `mpirun --hostfile hosts -np 2 -x OMP_NUM_THREADS ./hybrid`