## Experiment 5: tcpdump Final (Short Version)

### 1. Install tcpdump (Arch)

bash

```bash
sudo pacman -S tcpdump
tcpdump --version
```

If pacman is blocked by the college network, check whether it is already installed: `which tcpdump`.

### 2. Start the app (Experiment 3)

bash

```bash
sudo docker start backend frontend
sudo docker ps
```

Both must show `Up`.

### 3. Capture command (one command, shows only the name line)

**Terminal 1:**

bash

```bash
sudo tcpdump -i any -A -l -s 0 port 5000 2>/dev/null | grep --line-buffered "GET /save"
```

This prints only the line with the form data (name, email, phone).

If you want **only the name** value, use:

bash

```bash
sudo tcpdump -i any -A -l -s 0 port 5000 2>/dev/null | grep --line-buffered -o "name=[^& ]*"
```

### 4. Generate traffic

**Terminal 2:** open `http://localhost:8080`, fill in the form, and click **Submit**.  
Or use curl:

bash

```bash
curl "http://localhost:5000/save?name=Ravi&email=ravi@mail.com&phone=9876543210"
```

### 5. Output

With the first command:

```
GET /save?name=Ravi&email=ravi@mail.com&phone=9876543210 HTTP/1.1
```

With the second command (name only):

```
name=Ravi
```

Stop with `Ctrl+C`.

### Notes

- With `-i any`, the same packet may show twice (once on `lo`, once on `docker0`). That is normal. To avoid it, use `-i lo` instead of `-i any`.
- If nothing appears, check that the backend is `Up` and that you used the right port (5000).
- `-A` prints the packet as text, and `-l` shows lines immediately (needed when piping to grep).

### Viva line

“tcpdump captured the HTTP request on port 5000, and because HTTP is unencrypted, the name, email, and phone are readable in plain text.”