## Experiment: YouTube Data API in Colab (Playlist Details)

**Aim:** give a YouTube playlist link, call the YouTube Data API from Colab, and get the playlist name, total videos, each video’s name, views, likes, and duration, then show a table and chart.

Colab runs on Google’s servers, so your college proxy and firewall don’t affect it.

---

### Part A: Get a YouTube API key (one time)

1. Go to `https://console.cloud.google.com` and sign in with a Google account.
2. Top bar > project dropdown > **New Project**, name it `yt-api`, and click **Create**.
3. Menu > **APIs & Services** > **Library**, search **YouTube Data API v3**, and click **Enable**.
4. Menu > **APIs & Services** > **Credentials** > **Create credentials** > **API key**.
5. Copy the key (it looks like `AIzaSy...`).

The free quota is 10,000 units per day. Each list request here costs 1 unit, so this experiment uses very little.

---

### Part B: Set up Colab

1. Open `https://colab.research.google.com` and click **New notebook**.
2. Click the **key icon (Secrets)** in the left sidebar > **Add new secret**.
3. Name: `YT_API_KEY`, Value: your key, and turn on **Notebook access**.

Never paste the key into the code, because it gets exposed when you share the notebook.

Press **Shift+Enter** to run each cell.

---

### Part C: Code (one cell each)

**Cell 1: setup**

python

```python
import requests, re
import pandas as pd
from google.colab import userdata

API_KEY = userdata.get('YT_API_KEY')
BASE = "https://www.googleapis.com/youtube/v3"
```

**Cell 2: paste the playlist link and get its ID**

python

```python
link = "https://www.youtube.com/playlist?list=PUT_YOUR_PLAYLIST_ID_HERE"

pid = re.search(r"list=([\w-]+)", link).group(1)
print("Playlist ID:", pid)
```

Replace the link with any public playlist link. A link like `watch?v=xxxx&list=PLxxxx` also works, since only the `list=` part is read.

**Cell 3: playlist details**

python

```python
r = requests.get(BASE + "/playlists", params={
    "part": "snippet,contentDetails",
    "id": pid,
    "key": API_KEY
}).json()

item = r["items"][0]
print("Playlist name :", item["snippet"]["title"])
print("Channel       :", item["snippet"]["channelTitle"])
print("Total videos  :", item["contentDetails"]["itemCount"])
print("Created on    :", item["snippet"]["publishedAt"][:10])
```

**Cell 4: get all video names (handles more than 50 videos)**

python

```python
videos = []
token = None

while True:
    r = requests.get(BASE + "/playlistItems", params={
        "part": "snippet,contentDetails",
        "playlistId": pid,
        "maxResults": 50,
        "pageToken": token,
        "key": API_KEY
    }).json()

    for i in r.get("items", []):
        videos.append({
            "video_id": i["contentDetails"]["videoId"],
            "title": i["snippet"]["title"]
        })

    token = r.get("nextPageToken")
    if not token:
        break

print("Videos fetched:", len(videos))
```

Each request returns at most 50 items, so the loop follows `nextPageToken` until the last page.

**Cell 5: views, likes, and duration for each video**

python

```python
def to_minutes(d):                      # converts PT1H2M30S to minutes
    h = re.search(r"(\d+)H", d); m = re.search(r"(\d+)M", d); s = re.search(r"(\d+)S", d)
    return round((int(h.group(1)) if h else 0) * 60 +
                 (int(m.group(1)) if m else 0) +
                 (int(s.group(1)) if s else 0) / 60, 2)

ids = [v["video_id"] for v in videos]
rows = []

for i in range(0, len(ids), 50):
    chunk = ids[i:i+50]
    r = requests.get(BASE + "/videos", params={
        "part": "snippet,statistics,contentDetails",
        "id": ",".join(chunk),
        "key": API_KEY
    }).json()
    for v in r["items"]:
        rows.append({
            "title": v["snippet"]["title"],
            "published": v["snippet"]["publishedAt"][:10],
            "views": int(v["statistics"].get("viewCount", 0)),
            "likes": int(v["statistics"].get("likeCount", 0)),
            "duration_min": to_minutes(v["contentDetails"]["duration"])
        })

df = pd.DataFrame(rows)
df
```

The `/videos` endpoint accepts up to 50 IDs per call, so batching keeps the quota use low.

**Cell 6: summary**

python

```python
print("Total videos      :", len(df))
print("Total views       :", df["views"].sum())
print("Total likes       :", df["likes"].sum())
print("Total duration    :", round(df["duration_min"].sum() / 60, 2), "hours")
print("Most viewed video :", df.loc[df["views"].idxmax(), "title"])
```

**Cell 7: chart of the top 10 videos by views**

python

```python
df.sort_values("views", ascending=False).head(10).plot(
    x="title", y="views", kind="barh", legend=False,
    title="Top 10 videos by views", figsize=(8, 5)).invert_yaxis()
```

**Cell 8: save to CSV (optional)**

python

```python
df.to_csv("playlist_data.csv", index=False)
```

The file appears in the left sidebar under the folder icon, where you can download it.

---

### Part D: If you have a single video link instead

python

```python
link = "https://www.youtube.com/watch?v=PUT_VIDEO_ID_HERE"
vid = re.search(r"(?:v=|youtu\.be/)([\w-]{11})", link).group(1)

r = requests.get(BASE + "/videos", params={
    "part": "snippet,statistics,contentDetails",
    "id": vid, "key": API_KEY
}).json()["items"][0]

print("Title    :", r["snippet"]["title"])
print("Channel  :", r["snippet"]["channelTitle"])
print("Views    :", r["statistics"]["viewCount"])
print("Likes    :", r["statistics"].get("likeCount"))
print("Comments :", r["statistics"].get("commentCount"))
print("Duration :", r["contentDetails"]["duration"])
```

---

### Troubleshooting

|Error|Fix|
|---|---|
|`KeyError: 'items'`|The response is an error. Run `print(r)` to see the message|
|`403 keyInvalid`|Wrong or missing key. Check the secret name `YT_API_KEY` and that Notebook access is on|
|`403 accessNotConfigured`|YouTube Data API v3 isn’t enabled for the project (Part A, step 3)|
|`403 quotaExceeded`|The daily quota is used up. Try again tomorrow or use another project|
|`IndexError` in Cell 3|The playlist is private or the ID is wrong. Use a public playlist|
|`likeCount` missing|The channel hides likes, which is why the code uses `.get()`|
|`SecretNotFoundError`|The secret isn’t created or the name doesn’t match exactly|
|A “Mix” or auto-generated playlist (ID starts with `RD`) fails|Use a normal user-created playlist|

---

### Report content

- **Aim:** fetch YouTube playlist data using the YouTube Data API v3 in Colab
- **Screenshots:** the playlist details output (Cell 3), the DataFrame table (Cell 5), the summary (Cell 6), and the bar chart (Cell 7)
- **Conclusion:** REST APIs return JSON, which Python’s `requests` fetches and `pandas` turns into tables for analysis.

### Viva answers

- **What is the YouTube Data API?** A REST API from Google that gives access to YouTube data such as videos, playlists, and channels as JSON.
- **Why an API key?** It identifies your project and counts your quota usage.
- **What is pagination?** The API returns a limited number of items per call (50 max), so you use `nextPageToken` to fetch the next page.
- **Which endpoints did we use?** `/playlists` (details), `/playlistItems` (video list), and `/videos` (statistics).
- **Why use Colab Secrets?** To keep the API key out of the code.

### Flow to remember

1. Get an API key (enable YouTube Data API v3) and save it in Colab Secrets.
2. Paste the playlist link and extract the ID with `re`.
3. Call `/playlists` for the name and total count.
4. Loop `/playlistItems` for all titles.
5. Call `/videos` for views, likes, and duration, then build the DataFrame.
6. Print the summary and plot the chart.

If you need the exam to be quicker, I can cut this down to a single cell that prints the name, total videos, and titles only.